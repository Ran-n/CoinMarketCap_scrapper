#  coinmarketcap_scrapper

Python wrapper for the [CoinMarketCap](https://coinmarketcap.com/) website with GPLv3 license.
