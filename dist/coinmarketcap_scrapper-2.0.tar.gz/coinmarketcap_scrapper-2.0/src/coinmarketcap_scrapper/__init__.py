'''
info coinmarketcap_scrapper
'''

__version__ = '2.0'
__author__ = 'Ran#'
__credits__ = 'Ran#'
__license__ = 'GPLv3'
